package lk.ac.vau.fas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComputerAccessoriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComputerAccessoriesApplication.class, args);
	}

}
