package lk.ac.vau.fas.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import lk.ac.vau.fas.entity.Accessory;
import lk.ac.vau.fas.entity.MyAccessoryList;
import lk.ac.vau.fas.service.AccessoryService;
import lk.ac.vau.fas.service.MyAccessoryListService;

@Controller
public class AccessoryController {
	
	@Autowired
	private AccessoryService service;
	
	@Autowired
	private MyAccessoryListService myAccessoryService;
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	
	@GetMapping("/accessory_register")
	public String AccessoryRegister() {
		return "AccessoryRegister";
	}
	
	@GetMapping("/available_accessories")
	public ModelAndView AvailableAccessories() {
		List<Accessory>list=service.getAllAccessory();
		return new ModelAndView("AvailableAccessories","accessory",list);
		
	}
	
	@GetMapping("/order_accessories")
	public ModelAndView OrderAccessories() {
		List<Accessory>list=service.getAllAccessory();
		return new ModelAndView("OrderAccessories","accessory",list);
		
	}
	
	@PostMapping("/save")
	public String addAccessory(@ModelAttribute Accessory a)
	{
		service.save(a);
		return "redirect:/available_accessories";
	}
	
	@GetMapping("/my_accessories")
	public String getMyAccessories(Model model) {
		List<MyAccessoryList>list=myAccessoryService.getAllMyAccessories();
		model.addAttribute("accessory",list);
		return "myAccessory";
	}

	@RequestMapping("/myList/{id}")
	public String getMyList(@PathVariable("id") int id)
	{
		Accessory a = service.getAccessoryById(id);
		MyAccessoryList ma = new MyAccessoryList(a.getId(),a.getName(),a.getSupplier(),a.getPrice());
		myAccessoryService.saveMyAccessories(ma);
		
		return "redirect:/my_accessories";
	}
	
	@RequestMapping("/editAccessory/{id}")
	public String editAccessory(@PathVariable("id") int id,Model model)
	{
		Accessory a = service.getAccessoryById(id);
		model.addAttribute("accessory", a);
		return "AccessoryEdit";
	}
	
	@RequestMapping("/deleteAccessory/{id}")
	public String deleteAccessory(@PathVariable("id") int id)
	{
		service.deleteById(id);
		return "redirect:/available_accessories"; 
	}
}
