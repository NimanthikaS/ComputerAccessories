package lk.ac.vau.fas.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lk.ac.vau.fas.entity.Accessory;
import lk.ac.vau.fas.repository.AccessoryRepository;

@Service
public class AccessoryService {

	@Autowired
	private AccessoryRepository aRepo;

	public void save(Accessory a) {
		aRepo.save(a);
	}

	public List<Accessory> getAllAccessory() {
		return aRepo.findAll();
	}

	public Accessory getAccessoryById(int id) {
		return aRepo.findById(id).get();
	}

	public void deleteById(int id) {
		aRepo.deleteById(id);
	}
}
