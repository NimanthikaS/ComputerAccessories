package lk.ac.vau.fas.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lk.ac.vau.fas.entity.MyAccessoryList;
import lk.ac.vau.fas.repository.MyAccessoryRepository;

@Service
public class MyAccessoryListService {
	
	@Autowired
	private MyAccessoryRepository myAccessory;
	
	public void saveMyAccessories(MyAccessoryList accessory)
	{
		myAccessory.save(accessory);
	}
	
	public List<MyAccessoryList> getAllMyAccessories()
	{
		return myAccessory.findAll();
	}
	
	public void deleteById(int id)
	{
		myAccessory.deleteById(id);
	}

}
